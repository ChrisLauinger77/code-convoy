import json,os,subprocess,sys,tempfile,time
from pathlib import Path
image=Path(sys.argv[1]).resolve();mode=sys.argv[2]
with tempfile.TemporaryDirectory(prefix='codeconvoy-runtime-native-') as d:
 home=Path(d);env=dict(os.environ,HOME=d,XDG_CONFIG_HOME=d+'/config',XDG_DATA_HOME=d+'/data',XDG_CACHE_HOME=d+'/cache')
 for key in ('WAYLAND_DISPLAY','WAYLAND_SOCKET','APPIMAGE_EXTRACT_AND_RUN'):env.pop(key,None)
 if mode=='extract':env['APPIMAGE_EXTRACT_AND_RUN']='1'
 before=set(Path('/proc/self/mountinfo').read_text().splitlines())
 with (home/'output.log').open('w+b') as log:
  process=subprocess.Popen([str(image)],env=env,stdout=log,stderr=log,start_new_session=True)
  try:
   deadline=time.monotonic()+30;window=None
   while time.monotonic()<deadline:
    if process.poll() is not None:raise RuntimeError('startup exited '+str(process.returncode))
    result=subprocess.run(['wmctrl','-lp'],env=env,capture_output=True,text=True,check=True)
    for line in result.stdout.splitlines():
     fields=line.split(None,4)
     if len(fields)==5 and 'CodeConvoy' in fields[4]:
      try:
       if os.getpgid(int(fields[2]))==process.pid:window=fields[0]
      except (ProcessLookupError,ValueError):pass
    if window and list(home.rglob('app.lock')):break
    time.sleep(.1)
   else:raise RuntimeError('no owned window/store')
   time.sleep(2)
   mounts=set(Path('/proc/self/mountinfo').read_text().splitlines())-before
   app_mounts={m for m in mounts if ' - fuse' in m and '.mount_' in m}
   if mode=='fuse' and not app_mounts:raise RuntimeError('no FUSE mount')
   if mode=='extract' and app_mounts:raise RuntimeError('extraction unexpectedly mounted FUSE')
   subprocess.run(['wmctrl','-ic',window],env=env,check=True)
   code=process.wait(timeout=30)
   if code:raise RuntimeError('normal shutdown status '+str(code))
   for _ in range(50):
    if not app_mounts.intersection(Path('/proc/self/mountinfo').read_text().splitlines()):break
    time.sleep(.1)
   else:raise RuntimeError('FUSE mount survived normal close')
   log.flush();log.seek(0);output=log.read().decode(errors='replace')
   print(json.dumps({'image':image.name,'mode':mode,'normal_close':code,'owned_window':True,'store_created':True,'fuse_mount_observed':bool(app_mounts),'mount_cleaned':True,'modified_libfuse_marker':'CodeConvoy modified libfuse relink demonstration' in output,'desktop':'native Debian Forky GNOME XWayland'},sort_keys=True))
  except BaseException:
   log.flush();log.seek(0);print(log.read().decode(errors='replace'));raise
  finally:
   if process.poll() is None:
    import signal
    os.killpg(process.pid,signal.SIGTERM)
    try:process.wait(timeout=10)
    except subprocess.TimeoutExpired:os.killpg(process.pid,signal.SIGKILL);process.wait()
