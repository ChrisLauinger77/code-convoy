AppImage runtime verification evidence, 2026-10-16.
See docs/appimage-runtime-validation.md for commands, source identities, scope and interpretation.
This archive intentionally contains no runtime or application binaries, compiler packages or credentials.
The final-image checks are recorded after packaging and are not embedded back into that same image.
The source-only kit and the stock/modified link audits are independently checksum-bound by the license catalog.
